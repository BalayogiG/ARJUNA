package com.example.arjuna;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

public class MorseCodeGenerator {
    private final Context context;
    private final long dashDuration = 500;
    private final long dotDuration = 200;
    private final long gapDuration = 1000;
    private final long interCharacterGapDuration = 500;
    private final Vibrator vibrator;

    public MorseCodeGenerator(Context context2) {
        context = context2;
        vibrator = (Vibrator) context2.getSystemService(Context.VIBRATOR_SERVICE);
    }

    public void generateMorseCodeVibration(int number) {
        if (number >= 0 && number <= 9) {
            vibrateMorseCode(getMorseCodeForNumber(number));
        }
    }

    private String getMorseCodeForNumber(int number) {
        return new String[]{"-----", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----."}[number];
    }

    private void vibrateMorseCode(String morseCode) {
        for (int i = 0; i < morseCode.length(); i++) {
            char c = morseCode.charAt(i);
            if (c == '.') {
                VibrationEffect vibrationEffect1 = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrationEffect1 = VibrationEffect.createOneShot(this.dotDuration, -1);
                }
                vibrator.cancel();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(vibrationEffect1);
                }
            } else if (c == '-') {
                VibrationEffect vibrationEffect12 = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrationEffect12 = VibrationEffect.createOneShot(this.dashDuration, -1);
                }
                vibrator.cancel();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(vibrationEffect12);
                }
            }
            try {
                Thread.sleep(this.gapDuration);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        try {
            Thread.sleep(this.interCharacterGapDuration);
        } catch (InterruptedException e2) {
            e2.printStackTrace();
        }
    }
}
