package com.example.arjuna;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Practice extends AppCompatActivity {

    String[] bmap = {"0111", "1000", "1010", "1100", "1101", "1001", "1110", "1111", "1011", "0110"};
    Button btnContinue;
    Button btnSubmit;
    Button btnclear;
    Button btngeneratePIN;
    String digit = "";
    EditText enteredPIN;
    String gPIN = "";
    TextView genPIN;
    String generatedPassword = "";
    String pin = "";
    String pins = "";
    String posId = "";
    SwipeListener swipeListener;
    SwipeListener swipeListener1;
    SwipeListener swipeListener2;
    SwipeListener swipeListener3;
    RelativeLayout v1;
    RelativeLayout v2;
    RelativeLayout v3;
    RelativeLayout v4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practice);

        genPIN = (TextView) findViewById(R.id.genPin);
        enteredPIN = (EditText) findViewById(R.id.enteredPIN);
        btngeneratePIN = (Button) findViewById(R.id.btngenerate);

        v1 = findViewById(R.id.pos1);
        swipeListener = new SwipeListener((v1));

        v2 = findViewById(R.id.pos2);
        swipeListener1 = new SwipeListener((v2));

        v3 = findViewById(R.id.pos3);
        swipeListener2 = new SwipeListener((v3));

        v4 = findViewById(R.id.pos4);
        swipeListener3 = new SwipeListener((v4));

        btnclear = (Button) findViewById(R.id.btnclear);
        btnContinue = (Button) findViewById(R.id.btncontinue);
        btnSubmit = (Button) findViewById(R.id.btnsubmit);
        generatedPassword = String.format("%04d", new Object[]{Integer.valueOf(new Random().nextInt(10000))});
        genPIN.setText("Enter the PIN: " + this.generatedPassword);
        btngeneratePIN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random random = new Random();
                generatedPassword = String.format("%04d", new Object[]{Integer.valueOf(random.nextInt(10000))});
                genPIN.setText("Enter the PIN: " + Practice.this.generatedPassword);
                enteredPIN.setText("");
                pin = "";
                digit = "";
            }
        });

        btnclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enteredPIN.setText("");
                pin = "";
                digit = "";
                pins = "";
                posId = "";
                gPIN = "";
            }
        });

        btnContinue.setOnClickListener(new View.OnClickListener() {
            final Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

            @Override
            public void onClick(View view) {
                if (Practice.this.pins.contentEquals("pos2pos3pos4")) {
                    StringBuilder sb = new StringBuilder();
                    Practice practice = Practice.this;
                    practice.gPIN = sb.append(practice.gPIN).append("0").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(0);
                }
                if (Practice.this.pins.contentEquals("pos1")) {
                    StringBuilder sb2 = new StringBuilder();
                    Practice practice2 = Practice.this;
                    practice2.gPIN = sb2.append(practice2.gPIN).append("1").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(1);
                }
                if (Practice.this.pins.contentEquals("pos1pos3")) {
                    StringBuilder sb3 = new StringBuilder();
                    Practice practice3 = Practice.this;
                    practice3.gPIN = sb3.append(practice3.gPIN).append("2").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(2);
                }
                if (Practice.this.pins.contentEquals("pos1pos2")) {
                    StringBuilder sb4 = new StringBuilder();
                    Practice practice4 = Practice.this;
                    practice4.gPIN = sb4.append(practice4.gPIN).append("3").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(3);
                }
                if (Practice.this.pins.contentEquals("pos1pos2pos4")) {
                    StringBuilder sb5 = new StringBuilder();
                    Practice practice5 = Practice.this;
                    practice5.gPIN = sb5.append(practice5.gPIN).append("4").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(4);
                }
                if (Practice.this.pins.contentEquals("pos1pos4")) {
                    StringBuilder sb6 = new StringBuilder();
                    Practice practice6 = Practice.this;
                    practice6.gPIN = sb6.append(practice6.gPIN).append("5").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(5);
                }
                if (Practice.this.pins.contentEquals("pos1pos2pos3")) {
                    StringBuilder sb7 = new StringBuilder();
                    Practice practice7 = Practice.this;
                    practice7.gPIN = sb7.append(practice7.gPIN).append("6").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(6);
                }
                if (Practice.this.pins.contentEquals("pos1pos2pos3pos4")) {
                    StringBuilder sb8 = new StringBuilder();
                    Practice practice8 = Practice.this;
                    practice8.gPIN = sb8.append(practice8.gPIN).append("7").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(7);
                }
                if (Practice.this.pins.contentEquals("pos1pos3pos4")) {
                    StringBuilder sb9 = new StringBuilder();
                    Practice practice9 = Practice.this;
                    practice9.gPIN = sb9.append(practice9.gPIN).append("8").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(8);
                }
                if (Practice.this.pins.contentEquals("pos2pos3")) {
                    StringBuilder sb10 = new StringBuilder();
                    Practice practice10 = Practice.this;
                    practice10.gPIN = sb10.append(practice10.gPIN).append("9").toString();
                    Practice.this.enteredPIN.setText(Practice.this.gPIN);
                    new MorseCodeGenerator(view.getContext()).generateMorseCodeVibration(9);
                }
                Practice.this.pins = "";

            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Practice.this.generatedPassword.contentEquals(Practice.this.enteredPIN.getText())) {
                    Toast.makeText(Practice.this, "PIN Entry Success", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Practice.this, "PIN Entry failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private class SwipeListener implements View.OnTouchListener {
        GestureDetector gestureDetector;

        SwipeListener(View view){
            int thresold = 100;
            int velocity_thresold = 100;
            GestureDetector.SimpleOnGestureListener listener = new GestureDetector.SimpleOnGestureListener(){
                @Override
                public boolean onDown(MotionEvent e) {
                    return true;
                }

                @Override
                public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                    float yDiff = e2.getY() - e1.getY();
                    try {
                        if (Math.abs(yDiff) > thresold && Math.abs(velocityY) > velocity_thresold) {
                            if (yDiff < 0) {
                                // up
                                posId = getResources().getResourceEntryName(view.getId());
                                generatePIN(posId);
                                posId = "";
                            }
                            return true;
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    return false;
                }
            };

            gestureDetector = new GestureDetector(listener);
            view.setOnTouchListener(this);
        }

        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return gestureDetector.onTouchEvent(motionEvent);
        }
    }

    /* access modifiers changed from: private */
    public void generatePIN(String posId2) {
        this.pins += posId2;
    }
}